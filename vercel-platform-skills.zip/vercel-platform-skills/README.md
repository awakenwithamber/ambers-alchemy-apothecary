# vercel-platform-skills

A Vercel platform specialist agent (`vercel-platform-expert`) plus 28 skills that teach coding agents to ship secure, correct Vercel code.

| Area | Skills |
|---|---|
| Firewall & hardening (6) | firewall-overview, firewall-waf-custom-rules, firewall-bot-protection, firewall-attack-challenge-mode, firewall-rate-limiting, deployment-hardening |
| Environment variables & OIDC (5) | env-secure-dotenv, env-vercel-cli-workflows, env-oidc-tokens, env-validation-typesafety, env-secret-rotation |
| AI Gateway (6) | ai-gateway-setup, ai-gateway-routing-failover, ai-gateway-model-tiering, ai-gateway-byok, ai-gateway-budgets-observability, ai-gateway-coding-agents |
| Sandbox (5) | sandbox-basics, sandbox-untrusted-code, sandbox-network-firewall, sandbox-files-git-ports, sandbox-agent-tools |
| Auth (6) | auth-provider-selection, auth-betterauth, auth-clerk, auth-descope, auth-auth0, marketplace-provisioning |

## Install

### Option A — Claude Code plugin from GitHub (recommended)
1. Push this folder to a GitHub repo, e.g. `awakenwithamber/vercel-platform-skills`.
2. In Claude Code:
   ```
   /plugin marketplace add awakenwithamber/vercel-platform-skills
   /plugin install vercel-platform-skills@awaken-plugins
   ```

### Option B — Drop into a single project
Copy into the project repo:
```
.claude/agents/vercel-platform-expert.md   ← from agents/
.claude/skills/<each skill folder>          ← from skills/
```
Commit, and every Claude Code session in that repo (including Claude Code on the web/mobile) picks them up.

### Option C — Other agents (Cursor, Codex, Copilot…)
With the repo on GitHub: `npx skills add <owner>/<repo>` (skills.sh format), or copy `skills/` wherever that agent reads skills.

## Use
- Agent: "Use the vercel-platform-expert agent to lock down the login route."
- Skill directly: `/vercel-platform-skills:firewall-rate-limiting` (plugin install) or just describe the task; skills trigger from their descriptions.

## Relationship to the official Vercel plugin
Vercel maintains `npx plugins add vercel/vercel-plugin` (35+ skills, auto-updated). This pack is namespaced separately so both can run together. Use the official one for breadth and freshness; use this one for focused, customizable guidance on these five areas.

## Keeping it current
Skills reflect Vercel docs as of September 2026. Each ends with a docs link; the agent is instructed to trust installed package types over the skill text when they disagree.
