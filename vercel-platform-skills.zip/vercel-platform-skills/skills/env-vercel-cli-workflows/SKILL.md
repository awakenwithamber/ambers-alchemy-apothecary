---
name: env-vercel-cli-workflows
description: Manage Vercel environment variables with the CLI — vercel env add, pull, ls, rm, update; Production/Preview/Development scopes; branch-specific preview values; custom environments; sensitive variables; and when redeploys are required. Use whenever the user or agent needs to add, change, sync, list, or remove a Vercel environment variable, fix "env var undefined in production", or set different values per environment or branch.
---

# `vercel env` workflows

Prereq: `vercel login` and `vercel link` (creates `.vercel/project.json`). Agents should add `--yes` / pipe values to avoid interactive prompts.

## Core commands

```bash
vercel env ls                                   # list names + environments (values hidden)
vercel env pull .env.local                      # development values → local file
vercel env pull .env.preview.local --environment=preview
vercel env add STRIPE_SECRET_KEY production     # prompts for value
printf '%s' "$VALUE" | vercel env add STRIPE_SECRET_KEY production   # non-interactive
vercel env add FEATURE_FLAG preview my-branch   # branch-specific preview value
vercel env rm OLD_KEY production --yes
```
Use `printf '%s'` (not `echo`) so no trailing newline sneaks into the value.

## Environments

| Scope | Used by |
|---|---|
| Production | Production deployments (main branch / promoted) |
| Preview | All non-production branch deployments (optionally per-branch overrides) |
| Development | `vercel dev` and `vercel env pull` |
| Custom (Pro+) | e.g. `staging`; target with `--environment=staging` where supported |

Add a variable to **each** scope it's needed in. The #1 cause of "works locally, undefined in prod" is a var only added to Development.

## Sensitive variables

Mark secrets as **Sensitive** (dashboard toggle or the CLI's sensitive option; check `vercel env add --help` for the current flag). Sensitive values can't be read back in the dashboard and aren't pulled into Development. Store the original in a password manager if you'll need it again.

## Changes need a redeploy

Env vars are captured per deployment. After changing a value:
```bash
vercel redeploy <deployment-url>       # or push a commit / vercel --prod
```
`NEXT_PUBLIC_*` values are baked in at build; a redeploy without rebuilding cache is safest when they change.

## System variables worth knowing

`VERCEL_ENV` (production|preview|development), `VERCEL_URL` (deployment host, no protocol), `VERCEL_PROJECT_PRODUCTION_URL`, `VERCEL_GIT_COMMIT_SHA`, `VERCEL_OIDC_TOKEN` (see `env-oidc-tokens`). Enable "Automatically expose System Environment Variables" if they're missing.

## Agent checklist

1. `vercel env ls` before assuming names exist.
2. Add to every needed scope.
3. Redeploy.
4. Verify with a server-only debug check (boolean presence only — never print values).

Docs: https://vercel.com/docs/cli/env
