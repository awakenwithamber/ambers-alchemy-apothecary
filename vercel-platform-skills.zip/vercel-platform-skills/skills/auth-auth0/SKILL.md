---
name: auth-auth0
description: Add Auth0 to a Next.js app on Vercel with @auth0/nextjs-auth0 v4 — Marketplace or manual provisioning, the Auth0Client, auto-mounted /auth/login /auth/logout /auth/callback routes via proxy/middleware, server-side getSession, callback and logout URLs for preview and production, and enterprise SSO. Use whenever the user mentions Auth0, Okta customer identity, enterprise SSO/SAML, or migrating from nextjs-auth0 v3.
---

# Auth0 on Next.js + Vercel (SDK v4)

## 1. Provision & env

```bash
vercel integration add auth0     # or create a Regular Web Application in the Auth0 dashboard
vercel env pull .env.local
vercel env ls                    # confirm names
```
The v4 SDK reads:
- `AUTH0_DOMAIN` (e.g. `your-tenant.us.auth0.com`, no protocol)
- `AUTH0_CLIENT_ID`, `AUTH0_CLIENT_SECRET` (Sensitive)
- `AUTH0_SECRET` — 32-byte hex for cookie encryption: `openssl rand -hex 32`
- `APP_BASE_URL` — production domain in Production

If the integration injected different names, map them rather than renaming at the provider.

## 2. Client instance

```bash
npm i @auth0/nextjs-auth0
```

```ts
// lib/auth0.ts
import { Auth0Client } from '@auth0/nextjs-auth0/server';
export const auth0 = new Auth0Client();
```

## 3. Proxy/middleware (mounts the auth routes)

```ts
// proxy.ts (Next.js 16) — middleware.ts on Next.js 15 and earlier
import type { NextRequest } from 'next/server';
import { auth0 } from './lib/auth0';

export async function proxy(request: NextRequest) {   // name the export `middleware` on Next 15
  return await auth0.middleware(request);
}

export const config = {
  matcher: ['/((?!_next/static|_next/image|favicon.ico|sitemap.xml|robots.txt).*)'],
};
```
This mounts `/auth/login`, `/auth/logout`, `/auth/callback`, `/auth/profile`. (v3 used `/api/auth/*` — update links when migrating.)

## 4. Use the session

```tsx
import { auth0 } from '@/lib/auth0';

export default async function Page() {
  const session = await auth0.getSession();
  if (!session) return <a href="/auth/login">Log in</a>;
  return <p>Welcome {session.user.name} · <a href="/auth/logout">Log out</a></p>;
}
```
Protect pages and routes by checking `getSession()` server-side and redirecting to `/auth/login`.

## 5. Callback URLs (common failure)

In the Auth0 application settings add:
- Allowed Callback URLs: `https://<prod-domain>/auth/callback`, `http://localhost:3000/auth/callback`
- Allowed Logout URLs: `https://<prod-domain>`, `http://localhost:3000`

Previews get unique URLs; use a stable preview domain (branch alias) or Auth0 wildcard support where allowed, and set `APP_BASE_URL` for Preview accordingly.

Docs: https://auth0.com/docs/quickstart/webapp/nextjs
