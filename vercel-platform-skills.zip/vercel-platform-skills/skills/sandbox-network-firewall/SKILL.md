---
name: sandbox-network-firewall
description: Configure Vercel Sandbox egress network policies — allow-all, deny-all, and user-defined domain/CIDR allowlists — plus credential brokering (inject Authorization headers so secrets never enter the sandbox), request proxying via forwardURL, matchers, and live policy updates at runtime. Use whenever a sandbox needs limited internet access, must call an API like AI Gateway or GitHub without holding the key, or the user worries about data exfiltration from sandboxed code.
---

# Sandbox network firewall

Three modes, changeable at runtime without restarting processes:

- `'allow-all'` — default. Full internet.
- `'deny-all'` — no egress at all, **including DNS**.
- **User-defined** — deny by default, allow listed domains / CIDRs.

## Allowlist

```ts
const sandbox = await Sandbox.create({
  networkPolicy: { allow: ['registry.npmjs.org', '*.github.com', 'ai-gateway.vercel.sh'] },
});
```
- `*.example.com` matches subdomains at any depth but **not** `example.com` — add both if needed.
- Wildcards replace whole labels only (`api*.x.com` is invalid).
- An empty policy (`{}`) behaves like deny-all.
- HTTPS is matched by SNI; plain HTTP can only be allowed by IP range. Postgres over TLS (`sslmode=require`) is supported by domain.
- Broad CIDRs (`0.0.0.0/0`) override domain scoping — avoid.

## Credential brokering (secrets never enter the VM)

```ts
const sandbox = await Sandbox.create({
  networkPolicy: {
    allow: {
      'ai-gateway.vercel.sh': [{
        transform: [{ headers: { Authorization: `Bearer ${process.env.AI_GATEWAY_API_KEY}` } }],
      }],
      'api.github.com': [{
        transform: [{ headers: { Authorization: `Bearer ${process.env.GITHUB_TOKEN}` } }],
      }],
    },
  },
});
```
Code inside calls those hosts without any key; the firewall injects it on the way out. Omit a `"*": []` catch-all unless you truly want the rest of the internet reachable.

## Live lockdown

```ts
const sb = await Sandbox.create();                         // start open
await sb.runCommand('npm', ['install']);                   // fetch deps
await sb.update({ networkPolicy: 'deny-all' });            // lock
await sb.runCommand('node', ['untrusted.js']);             // run with no egress
```

## Proxying & matchers

- `forwardURL: 'https://my-proxy.vercel.app/github'` routes a domain's traffic through your proxy (use `defineSandboxProxy` from `@vercel/sandbox/proxy`, which validates the attached `vercel-sandbox-oidc-token`).
- `match: { path, method, queryString, headers }` narrows which requests a rule **transforms or forwards** — matchers never block. To restrict a domain to certain paths, forward everything (no `match`) and reject in your proxy.

## Gotchas

- Domain fronting: an allowlisted SNI can carry a different `Host`. Prefer single-purpose hostnames, or pin `Host` via a `transform` rule.
- TLS is terminated only for domains with transform/forward rules; a per-sandbox CA is installed. Custom CA bundles must trust it.

Docs: https://vercel.com/docs/sandbox/concepts/firewall
