---
name: firewall-attack-challenge-mode
description: Emergency incident response for a Vercel site under active attack or a sudden malicious traffic flood — enabling Attack Challenge Mode, protecting automation that would break, identifying the attack in the live traffic view, and replacing the blanket challenge with targeted WAF rules. Use immediately when the user says their site is being attacked, DDoSed, flooded, hammered, has a huge unexplained traffic or bill spike, or is down from bot traffic.
---

# Attack Challenge Mode — incident runbook

Attack Challenge Mode puts the Vercel Security Checkpoint in front of **every** visitor to the project. Real browsers pass automatically after a short JS check; scripts and botnets don't. Verified bots (search engines) and your own project's internal requests are allowed through. It's available on all plans, and challenged requests aren't billed as usage.

## Step 1 — Turn it on (seconds)

Project → **Firewall** → **Bot Management / Attack Challenge Mode** → enable. (It can also be set through the firewall config REST API; verify the current field name in the API reference before scripting it.)

## Step 2 — Protect what will break

These cannot solve a JS challenge and will start failing:
- Payment and other webhooks (Stripe, Shopify, Clerk, etc.)
- Mobile apps and server-to-server API consumers
- Uptime monitors, cron jobs calling public URLs, CI smoke tests

Add a WAF custom rule with action **bypass** for those paths or a shared-secret header, positioned at the top. Confirm verified webhook providers aren't already covered before adding broad bypasses.

## Step 3 — Identify the attack

Firewall overview → live traffic → group by **IP**, **ASN**, **country**, **user agent**, **path**, and **JA4**. Look for the dimension where one value dominates.

## Step 4 — Replace the blanket with targeted rules

Using `firewall-waf-custom-rules`:
- Single source → IP block (narrow CIDR).
- One network → ASN rule → deny.
- One path (e.g. `/api/search`) → rate limit rule (`firewall-rate-limiting`).
- Distinctive fingerprint → JA4 rule → deny, with a persistent action.

## Step 5 — Turn it off

Once targeted rules hold (watch 15–30 minutes), disable Attack Challenge Mode. Leaving it on permanently adds friction for every real visitor.

## Step 6 — After action

- Check **Usage** for function/bandwidth spikes and **Spend Management** caps.
- Note the rules added in the audit log description.
- Consider permanent Bot Protection managed ruleset + BotID on the targeted routes.

Docs: https://vercel.com/docs/vercel-firewall/attack-challenge-mode
