---
name: deployment-hardening
description: Harden Vercel deployments — Deployment Protection (Vercel Authentication, password, Trusted IPs), protection bypass for automation, keeping previews out of search engines, security headers (CSP, HSTS, frame, referrer), sensitive env vars, and team/Git settings. Use whenever the user is preparing a production launch, asks for a security review or checklist, has exposed preview URLs, needs CI/e2e tests to reach protected previews, or wants security headers.
---

# Deployment hardening checklist

## 1. Deployment Protection (Settings → Deployment Protection)

- **Vercel Authentication**: require a Vercel login to view. Default for previews — keep it on. Consider "All deployments" except production domains.
- **Password Protection** / **Trusted IPs**: plan-dependent; use for client review links or internal tools.
- **Protection Bypass for Automation**: generates a secret for CI/e2e/webhooks. Send it as the `x-vercel-protection-bypass` header (add `x-vercel-set-bypass-cookie: true` for browser tests). It's exposed to builds as `VERCEL_AUTOMATION_BYPASS_SECRET`. Never paste it into client code.
- Agents/CLI can reach protected deployments with `vercel curl <url>` (aka `vc curl`) while logged in.

## 2. Keep previews private and unindexed

Preview deployments send `X-Robots-Tag: noindex` by default. Don't override it. Don't link previews publicly. Webhooks should point at production domains, not preview URLs.

## 3. Security headers

```ts
// next.config.ts
const securityHeaders = [
  { key: 'Strict-Transport-Security', value: 'max-age=63072000; includeSubDomains; preload' },
  { key: 'X-Content-Type-Options', value: 'nosniff' },
  { key: 'X-Frame-Options', value: 'DENY' },
  { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
  { key: 'Permissions-Policy', value: 'camera=(), microphone=(), geolocation=()' },
  // Add a Content-Security-Policy last; start with Content-Security-Policy-Report-Only
];

export default {
  async headers() {
    return [{ source: '/(.*)', headers: securityHeaders }];
  },
};
```

Non-Next projects: put the same list under `"headers"` in `vercel.json`. Roll out CSP as `Report-Only` first; auth providers (Clerk, Auth0, Descope), analytics, and Stripe need their domains allowlisted.

## 4. Secrets

- Mark secrets **Sensitive** so they can't be read back from the dashboard (see `env-vercel-cli-workflows`).
- Replace long-lived cloud keys with OIDC (`env-oidc-tokens`).
- Nothing secret behind `NEXT_PUBLIC_` (`env-secure-dotenv`).

## 5. Team & Git

- Enforce SSO/2FA for team members; least-privilege roles.
- Require approval before deploying PRs from forks (Git fork protection) so outside contributors can't read env vars in builds.
- Turn on the WAF managed rulesets and a baseline rate limit on auth (`firewall-rate-limiting`).

## 6. Launch verification

- `curl -sI https://<prod-domain> | grep -iE 'strict-transport|x-frame|content-security'`
- Open a preview URL in a private window → should require Vercel login.
- Confirm webhooks and cron still succeed after protection changes.

Docs: https://vercel.com/docs/deployment-protection
