---
name: firewall-waf-custom-rules
description: Create, test, and enforce Vercel WAF custom rules (log, deny, challenge, bypass, redirect, rate limit) by country, ASN, IP, user agent, path, header, cookie, or JA3/JA4 fingerprint — via the dashboard or the firewall REST API. Use whenever the user wants to block, challenge, or allow specific traffic on Vercel, write firewall rules as code, or respond to scanners or unwanted regions.
---

# Vercel WAF custom rules

A rule = **condition groups** (OR between groups, AND within a group) + **one action**.

**Parameters**: path, route, method, user_agent, header, query, cookie, hostname, protocol, geo (continent/country/state/city), ip, `geo_as_number` (ASN, digits only), JA3/JA4 digests.
**Operators**: `eq`, `inc` (is any of, array), `sub` (contains), `pre` (starts with), `suf` (ends with), `re` (PCRE). Any condition can set `neg: true`.
**Actions**: `log` (continue evaluating), `deny` (403, stop), `challenge` (JS checkpoint, stop), `bypass` (skip remaining custom rules), `redirect` (307, stop), `rate_limit`.

## Workflow (always)

1. Create the rule with action `log` and publish.
2. Watch Firewall → live traffic, grouped by the parameter you matched.
3. Tighten until matches contain only traffic you're willing to block.
4. Switch to `deny`/`challenge`, publish again.
5. Optional: add a **persistent action** (time-based block) so repeat offenders stay blocked at the platform layer.

## Dashboard path

Project → Firewall → ⋯ → Configure → Add New… → Rule → set If/Then → Save Rule → Review Changes → Publish.

## Rules as code (REST API)

```ts
// scripts/firewall-add-rule.ts — run with a VERCEL_TOKEN that has project access
const teamId = process.env.VERCEL_TEAM_ID!;
const projectId = process.env.VERCEL_PROJECT_ID!;

const res = await fetch(
  `https://api.vercel.com/v1/security/firewall/config?projectId=${projectId}&teamId=${teamId}`,
  {
    method: 'PATCH',
    headers: {
      Authorization: `Bearer ${process.env.VERCEL_TOKEN}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      action: 'rules.insert',
      id: null,
      value: {
        active: true,
        name: 'Block PHP probes',
        description: 'Site serves no PHP',
        conditionGroup: [
          { conditions: [{ type: 'path', op: 'suf', value: '.php' }] },
        ],
        action: {
          mitigate: { action: 'log', rateLimit: null, redirect: null, actionDuration: null },
        },
      },
    }),
  },
);
if (!res.ok) throw new Error(`Firewall update failed: ${res.status} ${await res.text()}`);
```

IP blocks use `action: 'ip.insert'` with `value: { action: 'deny', hostname: '*', ip: '12.34.56.0/24', notes: '...' }`. Limits: 3 IP rules on Hobby, 100 on Pro, 1000 on Enterprise.

## Starter recipes

- **Scanner paths** — path `re` `^/(wp-admin|wp-login\.php|xmlrpc\.php|\.env|\.git)` → deny.
- **Non-browser UA** — user_agent `re` `.*Mozilla.*` with `neg: true` → challenge (breaks curl, CI, monitors: add bypass first).
- **Cookieless API calls** — path `pre` `/api` AND cookie `sub` `session` negated → challenge. Exempt webhook routes.
- **Allow your own automation** — header `eq` a secret value (e.g. `x-internal-key`) → bypass, placed *above* stricter rules.

## Gotchas

- `sub` on path matches anywhere (`/blog/from-php-to-node` contains `php`). Prefer `suf` or anchored regex.
- Country comes from IP: VPN users and travelers match too.
- Rule order matters; drag or reorder so bypasses run first.
- Never put `VERCEL_TOKEN` in client code or commit it.

Docs: https://vercel.com/docs/vercel-firewall/vercel-waf/custom-rules · Recipes: https://vercel.com/kb/guide/suspicious-traffic-in-specific-countries
