---
name: env-validation-typesafety
description: Validate and type environment variables at build and startup so missing or malformed config fails fast — using Zod or @t3-oss/env-nextjs with separate server and client schemas. Use whenever the user adds several env vars, has runtime crashes from undefined env values, wants typed process.env, or is setting up a new Next.js project for production.
---

# Typed, validated env vars

Goal: a bad deploy fails at **build** with a clear message, not at 2am in a function.

## Recommended: `@t3-oss/env-nextjs`

```bash
npm i @t3-oss/env-nextjs zod
```

```ts
// env.ts
import { createEnv } from '@t3-oss/env-nextjs';
import { z } from 'zod';

export const env = createEnv({
  server: {
    DATABASE_URL: z.string().url(),
    STRIPE_SECRET_KEY: z.string().startsWith('sk_'),
    BETTER_AUTH_SECRET: z.string().min(32).optional(),
    AI_GATEWAY_API_KEY: z.string().optional(), // optional: OIDC used on Vercel
  },
  client: {
    NEXT_PUBLIC_SITE_URL: z.string().url(),
  },
  // Next.js inlines NEXT_PUBLIC_ vars only when referenced literally:
  experimental__runtimeEnv: {
    NEXT_PUBLIC_SITE_URL: process.env.NEXT_PUBLIC_SITE_URL,
  },
  emptyStringAsUndefined: true,
});
```

Import `env.ts` in `next.config.ts` (`import './env'`) so validation runs during `next build`. Then use `env.DATABASE_URL` everywhere instead of `process.env`.

Accessing a server var from a client component throws — that's the point.

## Plain Zod (any framework)

```ts
import 'server-only';
import { z } from 'zod';

const schema = z.object({
  DATABASE_URL: z.string().url(),
  NODE_ENV: z.enum(['development', 'test', 'production']).default('development'),
});

const parsed = schema.safeParse(process.env);
if (!parsed.success) {
  console.error('Invalid environment variables:', parsed.error.flatten().fieldErrors);
  throw new Error('Invalid environment variables');
}
export const env = parsed.data;
```
`flatten().fieldErrors` prints **names**, never values — keep it that way.

## Tips

- Mirror every schema key in `.env.example`.
- Mark vars that only exist on Vercel (`VERCEL_*`) optional so local builds pass.
- For CI builds that lack secrets, allow a `SKIP_ENV_VALIDATION=1` escape hatch only for lint/typecheck jobs, never deploys.
