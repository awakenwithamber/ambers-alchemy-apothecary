---
name: sandbox-agent-tools
description: Give an AI agent a safe code-execution tool backed by Vercel Sandbox using the AI SDK tool() API — one sandbox per run reused across tool calls, deny-all networking, output truncation, durable steps with the Workflow SDK, and cleanup. Use whenever the user builds an agent or chatbot that should run code, analyze data, execute scripts, act as a code interpreter, or test code it writes.
---

# Sandbox as an agent tool

The model writes code; the sandbox runs it. Your app never executes model-written code itself.

## Tool definition (AI SDK)

```ts
import { tool } from 'ai';
import { z } from 'zod';
import { Sandbox } from '@vercel/sandbox';

export function runCodeTool(runId: string) {
  return tool({
    description:
      'Run a Node.js script in an isolated sandbox. Files written earlier in this run persist. Print results to stdout.',
    inputSchema: z.object({
      filename: z.string().regex(/^[\w.-]+\.(js|mjs)$/),
      code: z.string().max(50_000),
    }),
    execute: async ({ filename, code }) => {
      const sandbox = await Sandbox.getOrCreate({
        name: `agent-${runId}`,     // one sandbox per run, reused across calls
        runtime: 'node24',
        timeout: 10 * 60_000,
        networkPolicy: 'deny-all',
      });
      await sandbox.writeFiles([{ path: filename, content: Buffer.from(code) }]);
      const cmd = await sandbox.runCommand({ cmd: 'node', args: [filename] });
      return {
        exitCode: cmd.exitCode,
        stdout: (await cmd.stdout()).slice(0, 10_000),
        stderr: (await cmd.stderr()).slice(0, 4_000),
      };
    },
  });
}
```

## Agent

```ts
import { ToolLoopAgent, stepCountIs } from 'ai';

const agent = new ToolLoopAgent({
  model: 'anthropic/claude-sonnet-5',
  instructions: 'Solve the task. Use run_code to compute; never guess numbers you can compute.',
  tools: { run_code: runCodeTool(runId) },
  stopWhen: stepCountIs(20),   // required ceiling
});
const result = await agent.generate({ prompt });
```

## Durable runs

Inside a Workflow SDK `'use workflow'` function, add `'use step'` as the first line of `execute` so each call is checkpointed and retried; `getOrCreate` with a run-keyed name means retries reattach to the same sandbox.

## Cleanup

Stop the sandbox when the run finishes (final step or `finally`). Timeouts are a backstop, not the plan.

## Hardening

- Return truncated output with exit codes so the model can self-correct.
- Need an API? Allowlist that host with a brokered credential (`sandbox-network-firewall`).
- Protect the route that starts runs with auth + rate limiting.
- Review `sandbox-untrusted-code` for the full checklist.
