---
name: marketplace-provisioning
description: Provision third-party services through the Vercel Marketplace from the CLI — vercel integration discover/add, non-interactive flags for agents, automatic environment-variable injection per environment, pulling credentials locally, installing provider agent skills, unified billing, and removing resources. Use whenever the user needs a database, auth provider, AI service, payments, or any Vercel integration (Neon, Supabase, Upstash, Clerk, Auth0, Descope, Stripe, etc.), or asks how to connect a service to their Vercel project.
---

# Vercel Marketplace provisioning

**Sequence: discover → add → pull env → build.** Provision first; build around the credentials and SDK the integration gives you.

## Discover

```bash
vercel integration categories
vercel integration discover --category <slug> --format=json   # structured output for agents
```

## Add (installs if needed, provisions a resource, connects to the linked project)

```bash
vercel link                                 # if not linked
vercel integration add clerk
vercel integration add neon --name app-db -e production -e preview   # flags skip prompts
```
`vercel install <name>` (alias `vercel i`) does the same. Run `vercel integration add --help` for the current flags (plan, region, environments, non-interactive `--yes`).

What happens:
- A Vercel-managed account/resource is created at the provider (or linked to an existing account with the same email).
- Credentials are injected as env vars on the project for the chosen environments.
- Many providers also install their agent skills into the project.
- Billing goes on the Vercel invoice.

## Pull and confirm

```bash
vercel env pull .env.local
vercel env ls        # read the actual injected names before writing code
```

## Auth-provider specifics

- **Clerk**: dev instance ↔ Development/Preview, prod instance ↔ Production; `NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY`, `CLERK_SECRET_KEY`.
- **Auth0 / Descope**: confirm injected names with `vercel env ls` and map them to what the SDK expects (`auth-auth0`, `auth-descope`).
- **BetterAuth** isn't a Marketplace product — provision its database (e.g. Neon) here instead.

## Management

- Manage plans, open the provider dashboard, or uninstall from the project's **Integrations/Storage** tab.
- Vercel-managed resources are deleted from Vercel, not from the provider's dashboard.
- Uninstalling removes injected env vars — redeploy afterward and expect breakage if code still references them.

Docs: https://vercel.com/kb/guide/using-coding-agents-to-procure-vercel-marketplace-integrations
