---
name: ai-gateway-model-tiering
description: Cut AI costs and latency by tiering models through Vercel AI Gateway — frontier models for planning and synthesis, mid-tier for tool loops, small fast models for extraction, classification, routing, and summaries — with a central model config and simple escalation. Use whenever the user's AI bill is high, responses are slow, they're choosing which model to use, or building a multi-step agent that uses one model for everything.
---

# Model tiering

Using the top frontier model for every call overpays for work a smaller model does just as well. Because Gateway models are just strings, tiering is a config change.

## Define tiers in one place

```ts
// lib/models.ts — verify IDs against the live catalog before shipping
export const MODELS = {
  frontier: 'anthropic/claude-fable-5',    // planning, hard reasoning, final synthesis
  standard: 'anthropic/claude-sonnet-5',   // agent tool loops, coding, most chat
  fast:     'google/gemini-2.5-flash',     // extraction, classification, summaries, titles
} as const;

export const FALLBACKS: Record<keyof typeof MODELS, string[]> = {
  frontier: ['openai/gpt-5'],
  standard: ['openai/gpt-5-mini'],
  fast:     ['openai/gpt-5-nano'],
};
```

```ts
import { generateObject } from 'ai';
import { MODELS, FALLBACKS } from '@/lib/models';

const { object } = await generateObject({
  model: MODELS.fast,
  providerOptions: { gateway: { models: FALLBACKS.fast } },
  schema,
  prompt: `Extract the claims from:\n${text}`,
});
```

## What goes where

| Task | Tier |
|---|---|
| Deciding the plan, judging ambiguous results, final report | frontier |
| Multi-step tool calling, code generation, customer chat | standard |
| JSON extraction, tagging, intent routing, chat titles, short summaries | fast |
| Embeddings | dedicated embedding model |

## Escalation pattern

Try `fast`; if validation fails (Zod parse error, low confidence, refusal), retry once on `standard`. Log escalations — frequent ones mean the task belongs on a higher tier.

## Measure, don't guess

Use Gateway logs to compare cost and latency per tier. Run a small eval set on the cheaper tier before moving a task down.
