---
name: env-oidc-tokens
description: Use Vercel OIDC tokens (VERCEL_OIDC_TOKEN) for keyless authentication to AI Gateway, Vercel Sandbox, and cloud providers (AWS IAM roles, GCP Workload Identity Federation, Azure) instead of long-lived secrets, including local development via vercel env pull and token expiry. Use whenever the user connects Vercel functions to AWS/GCP/Azure, sees VERCEL_OIDC_TOKEN, gets auth errors from AI Gateway or Sandbox locally, or wants to eliminate static cloud access keys.
---

# Vercel OIDC tokens

Vercel issues each deployment a short-lived, signed OIDC token identifying the team, project, and environment. Services that trust Vercel's issuer accept it instead of a static API key.

- **On Vercel**: available automatically (`VERCEL_OIDC_TOKEN` at build; provided per request at runtime — use the helpers below rather than reading headers yourself).
- **Locally**: `vercel env pull` writes a development `VERCEL_OIDC_TOKEN` into `.env.local`. It expires after roughly 12 hours — **re-run `vercel env pull` when you see 401s from AI Gateway or Sandbox.**
- Issuer: `https://oidc.vercel.com/<team_slug>` (team issuer mode). Audience: `https://vercel.com/<team_slug>`. Subject: `owner:<team>:project:<project>:environment:<env>`.

## Zero-config consumers

- **AI Gateway** and **Vercel Sandbox** SDKs pick up the token automatically. No keys in code.

## Getting the token in code

```ts
import { getVercelOidcToken } from '@vercel/oidc';
const token = await getVercelOidcToken();
```

## AWS (no access keys)

1. In IAM, add an OIDC identity provider for the issuer URL above with the audience above.
2. Create a role trusting it, with a condition on `sub` restricted to your project and environment, e.g. `owner:my-team:project:my-app:environment:production`.
3. In code:

```ts
import { awsCredentialsProvider } from '@vercel/functions/oidc';
import { S3Client } from '@aws-sdk/client-s3';

const s3 = new S3Client({
  region: process.env.AWS_REGION,
  credentials: awsCredentialsProvider({ roleArn: process.env.AWS_ROLE_ARN! }),
});
```
Only `AWS_ROLE_ARN` and `AWS_REGION` are env vars; neither is secret.

## GCP / Azure

Configure Workload Identity Federation (GCP) or federated credentials (Azure) against the same issuer/audience/subject, then exchange the token via the provider's STS. Follow Vercel's per-cloud guide for exact SDK wiring.

## Security notes

- Always scope trust policies by **project and environment** in `sub`; never trust the whole issuer.
- Separate roles for production vs preview so preview code can't touch prod data.
- Don't log the token; treat it like a credential even though it's short-lived.

Docs: https://vercel.com/docs/oidc
