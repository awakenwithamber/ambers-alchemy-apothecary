---
name: ai-gateway-coding-agents
description: Route AI coding agents — Claude Code, Codex, Cursor, Cline, OpenCode and others — through Vercel AI Gateway for one bill, spend tracking, request traces, provider fallback, and access to many models. Use whenever the user wants to point their coding agent at AI Gateway, consolidate agent spend, set a budget on agent usage, or configure ANTHROPIC_BASE_URL / OpenAI base URLs for an agent.
---

# Coding agents through AI Gateway

## Fastest path

```bash
vercel ai-gateway coding-agents setup                 # interactive
vercel ai-gateway coding-agents setup --agent claude-code
```
The CLI writes the right base URL and key configuration for the chosen agent.

## Endpoints

- OpenAI-protocol agents: `https://ai-gateway.vercel.sh/coding-agent/v1` (same behavior as `/v1`, but marks traffic as coding-agent traffic).
- Anthropic-protocol clients that append `/v1/messages` themselves: `https://ai-gateway.vercel.sh/coding-agent`.
- Some agents (Cline, OpenCode, etc.) have a built-in AI Gateway provider and only need your key.

## Manual Claude Code config (if not using the CLI)

Set in the environment Claude Code launches from, using an AI Gateway API key:
```bash
export ANTHROPIC_BASE_URL="https://ai-gateway.vercel.sh/coding-agent"
export ANTHROPIC_AUTH_TOKEN="$AI_GATEWAY_API_KEY"
```
Confirm exact variable names on the Claude Code agent page in the AI Gateway docs; prefer the CLI setup, which stays current.

## Recommendations

- Create a **dedicated API key with a budget** for agent use so a runaway loop can't drain credits (`ai-gateway-budgets-observability`).
- Separate keys per person or per machine for attribution.
- Keep the key in your shell profile or the agent's secure settings — never commit it to a repo the agent works in.

Docs: https://vercel.com/docs/ai-gateway/coding-agents
