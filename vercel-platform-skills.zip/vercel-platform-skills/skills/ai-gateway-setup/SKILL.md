---
name: ai-gateway-setup
description: Set up Vercel AI Gateway — one API for hundreds of models — with the AI SDK (plain "creator/model" strings), OIDC or API-key auth, and OpenAI- or Anthropic-compatible endpoints for other SDKs and languages. Use whenever the user wants to call an LLM from a Vercel app, switch providers, remove provider API keys, gets gateway auth errors, or asks how to use AI Gateway from Python, curl, or the OpenAI SDK.
---

# AI Gateway setup

## With the AI SDK (preferred)

A plain model string routes through AI Gateway by default. Format: `creator/model-name`.

```ts
import { generateText, streamText } from 'ai';

const { text } = await generateText({
  model: 'anthropic/claude-sonnet-5',
  prompt: 'Summarize this in one sentence: ...',
});

const result = streamText({ model: 'openai/gpt-5', messages });
return result.toUIMessageStreamResponse();
```

Browse current model IDs at https://vercel.com/ai-gateway/models or the catalog docs. **Don't hardcode model IDs from memory** — check the catalog; names change often.

## Authentication

| Where | How |
|---|---|
| Deployed on Vercel | Automatic via `VERCEL_OIDC_TOKEN`. No keys. |
| Local dev | `vercel link` then `vercel env pull` (token expires ~12h; re-pull on 401). |
| Outside Vercel, or when you need a budget | Create an AI Gateway API key → set `AI_GATEWAY_API_KEY`. |

If both exist, the API key is used. Budgets attach to API keys (`ai-gateway-budgets-observability`).

## OpenAI-compatible endpoint (any language/SDK)

```ts
import OpenAI from 'openai';
const client = new OpenAI({
  apiKey: process.env.AI_GATEWAY_API_KEY,
  baseURL: 'https://ai-gateway.vercel.sh/v1',
});
const r = await client.chat.completions.create({
  model: 'anthropic/claude-sonnet-5',
  messages: [{ role: 'user', content: 'Hello' }],
});
```
Python works the same with `openai.OpenAI(base_url="https://ai-gateway.vercel.sh/v1", api_key=...)`. Clients that speak the Anthropic Messages protocol can point at the gateway's Anthropic-compatible surface (see `ai-gateway-coding-agents`).

## Explicit provider instance (optional)

```ts
import { gateway } from '@ai-sdk/gateway';
const model = gateway('google/gemini-2.5-flash');
```
Use when you need gateway-specific helpers (e.g. listing available models) or custom headers.

## Verify

```bash
curl https://ai-gateway.vercel.sh/v1/chat/completions \
  -H "Authorization: Bearer $AI_GATEWAY_API_KEY" -H 'Content-Type: application/json' \
  -d '{"model":"openai/gpt-5-mini","messages":[{"role":"user","content":"ping"}]}'
```
Then check **AI Gateway → Logs** in the dashboard for the request, tokens, latency, and cost.

Docs: https://vercel.com/docs/ai-gateway
