---
name: sandbox-files-git-ports
description: Work with files, git repositories, and live previews in Vercel Sandbox — clone a repo as the sandbox source (public or private), write and read files, run installs and builds, expose ports and get a public preview URL via sandbox.domain(), and run dev servers. Use whenever the user wants to build or test a repo in a sandbox, generate an app and preview it live, move files in or out of a sandbox, or run "preview this branch" style features.
---

# Files, git, and ports

## Start from a git repo

```ts
const sandbox = await Sandbox.create({
  source: {
    type: 'git',
    url: 'https://github.com/owner/repo.git',
    // private repos: supply credentials per the SDK docs (e.g. a GitHub token);
    // prefer credential brokering over embedding tokens in URLs
  },
  runtime: 'node24',
  ports: [3000],
  timeout: 10 * 60_000,
});
```
Other sources (tarballs, snapshots, custom images) are available — see the docs.

## Write files

```ts
await sandbox.writeFiles([
  { path: 'app/page.tsx', content: Buffer.from(generatedCode) },
  { path: 'data/input.json', content: Buffer.from(JSON.stringify(data)) },
]);
```
Paths are relative to the sandbox working directory. Validate generated paths (no `..`, no absolute paths outside the project).

## Read results back

Use the SDK's file-read API (check the installed version's types for `readFile` / download helpers), or print small outputs to stdout and read `await cmd.stdout()`. For large artifacts, upload them from inside the sandbox to Vercel Blob using a brokered credential rather than streaming through your function.

## Install, build, serve, preview

```ts
await sandbox.runCommand('npm', ['ci']);
await sandbox.runCommand({ cmd: 'npm', args: ['run', 'dev', '--', '-p', '3000'], detached: true });

const url = sandbox.domain(3000);   // public HTTPS URL for that exposed port
```
Ports must be declared in `ports` at creation. Wait for the server to be ready (poll `url` until 200) before handing it to users.

## Tips

- Use `npm ci` with a lockfile for reproducibility.
- Cache heavy setups with snapshots so later sandboxes boot pre-installed.
- Previews are served from the sandbox's domain — never proxy untrusted HTML through your app's origin.
- Stop the sandbox when the preview session ends.

Docs: https://vercel.com/docs/sandbox
