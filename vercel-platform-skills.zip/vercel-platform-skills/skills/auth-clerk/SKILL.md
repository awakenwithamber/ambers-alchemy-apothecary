---
name: auth-clerk
description: Add Clerk authentication to a Next.js app on Vercel — provision through the Vercel Marketplace (keys auto-synced, dev instance for preview/development, prod instance for production), ClerkProvider, prebuilt sign-in components, clerkMiddleware route protection in proxy.ts/middleware.ts, server-side auth(), organizations, and webhooks. Use whenever the user mentions Clerk or wants the fastest managed sign-in with prebuilt UI.
---

# Clerk on Next.js + Vercel

## 1. Provision

```bash
vercel integration add clerk     # installs, provisions, connects to the linked project
vercel env pull .env.local
```
This syncs `NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY` and `CLERK_SECRET_KEY`. Clerk's **development** instance maps to Vercel Development + Preview; the **production** instance maps to Production. Billing runs through Vercel. (Manual alternative: create an app at clerk.com and add the two keys yourself.)

## 2. Install & provider

```bash
npm i @clerk/nextjs
```

```tsx
// app/layout.tsx
import { ClerkProvider, SignedIn, SignedOut, SignInButton, UserButton } from '@clerk/nextjs';

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <ClerkProvider>
      <html lang="en">
        <body>
          <header>
            <SignedOut><SignInButton /></SignedOut>
            <SignedIn><UserButton /></SignedIn>
          </header>
          {children}
        </body>
      </html>
    </ClerkProvider>
  );
}
```

## 3. Route protection

```ts
// proxy.ts (Next.js 16) — use middleware.ts on Next.js 15 and earlier
import { clerkMiddleware, createRouteMatcher } from '@clerk/nextjs/server';

const isProtected = createRouteMatcher(['/dashboard(.*)', '/api/private(.*)']);

export default clerkMiddleware(async (auth, req) => {
  if (isProtected(req)) await auth.protect();
});

export const config = {
  matcher: [
    '/((?!_next|[^?]*\\.(?:html?|css|js(?!on)|jpe?g|webp|png|gif|svg|ttf|woff2?|ico|csv|docx?|xlsx?|zip|webmanifest)).*)',
    '/(api|trpc)(.*)',
  ],
};
```

## 4. Server-side checks

```ts
import { auth, currentUser } from '@clerk/nextjs/server';

export async function GET() {
  const { userId } = await auth();
  if (!userId) return new Response('Unauthorized', { status: 401 });
  // ...
}
```
Always re-check in route handlers and server actions; proxy protection alone isn't enough.

## 5. Extras

- Organizations/roles: enable in the Clerk dashboard, use `auth().orgRole` / `has({ role })`.
- Webhooks (user.created etc.): verify signatures with `verifyWebhook` from `@clerk/nextjs/webhooks` and exempt the webhook path from firewall challenges.
- Production: add your production domain in the Clerk production instance and set DNS records it asks for.

Docs: https://clerk.com/docs/guides/development/integrations/platforms/vercel-marketplace
