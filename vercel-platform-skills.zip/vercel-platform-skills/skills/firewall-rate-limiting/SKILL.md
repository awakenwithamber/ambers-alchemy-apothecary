---
name: firewall-rate-limiting
description: Rate limit Vercel routes to stop brute force, credential stuffing, API abuse, and runaway AI costs — using WAF rate-limit rules (no code) or the @vercel/firewall SDK for per-user/per-key limits inside functions. Use whenever the user wants to throttle requests, protect login/signup/password-reset/OTP endpoints, limit an AI or search endpoint, or cap requests per API key.
---

# Rate limiting on Vercel

## Option A — WAF rule (no code, preferred for auth endpoints)

Firewall → Configure → New Rule:
- **If**: Request Path matches regex `^/api/auth/(?:register|signup|login|signin|reset|otp)$`
- **Then**: Rate Limit → **Fixed Window**, 60s window, 10 requests, key **IP Address**
- **After limit**: Deny (or Challenge for softer UX)
- Save → Review Changes → Publish

Add a second rule for distributed attacks: same path, 100 requests / 60s keyed by **User Agent** or **JA4**.

## Option B — `@vercel/firewall` SDK (custom keys, e.g. per user or API key)

1. In the dashboard, create a rate-limit rule whose condition is the **@vercel/firewall** SDK trigger and give it an ID (e.g. `ai-chat`).
2. Call it in code:

```ts
// app/api/chat/route.ts
import { checkRateLimit } from '@vercel/firewall';
import { auth } from '@/lib/auth'; // whichever auth skill applies

export async function POST(request: Request) {
  const session = await auth(); // get a stable user identifier
  const { rateLimited } = await checkRateLimit('ai-chat', {
    request,
    rateLimitKey: session?.userId, // omit to key by the rule's default (IP)
  });
  if (rateLimited) {
    return new Response('Too many requests', { status: 429, headers: { 'Retry-After': '60' } });
  }
  // ...call the model
}
```

Use this for: per-user AI quotas, per-API-key limits for partners, limits that depend on plan tier. Verify the option names against the installed package's types.

## Sizing guidance

| Endpoint | Starting limit |
|---|---|
| Login / OTP / password reset | 5–10 per minute per IP |
| Signup | 3–5 per minute per IP + BotID |
| AI chat / generation | per user, sized to your cost budget |
| Public search / listing APIs | 60–120 per minute per IP |

## Gotchas

- Shared IPs (offices, mobile carriers, schools) hit IP limits together; key by user when authenticated.
- Return 429 with `Retry-After` from code so clients back off.
- Rate limiting is not auth. Unauthenticated expensive endpoints still need auth or BotID.
- Start with Log to see real request rates before enforcing.

Docs: https://vercel.com/docs/vercel-firewall/vercel-waf/rate-limiting · https://vercel.com/kb/guide/limit-abuse-with-rate-limiting
