---
name: ai-gateway-budgets-observability
description: Control and monitor AI spend on Vercel AI Gateway — API-key budgets that hard-stop requests at a limit, per-feature or per-environment keys, request logs with tokens, latency, and cost, tagging requests by user or feature, and Spend Management. Use whenever the user wants a spending cap, worries about runaway agent costs, needs cost per feature or customer, or is debugging slow or failing model calls.
---

# Budgets & observability

## Budgets (hard caps)

Budgets attach to **AI Gateway API keys**. The gateway checks the key's balance before each request and stops serving once the limit is reached.

Pattern: one key per workload or environment.

| Key | Budget | Set as |
|---|---|---|
| `prod-chat` | monthly cap sized to revenue | `AI_GATEWAY_API_KEY` in Production |
| `preview-dev` | small cap | `AI_GATEWAY_API_KEY` in Preview/Development |
| `research-agent` | per-run-sized cap | scoped to that project |

Setting `AI_GATEWAY_API_KEY` makes calls use the key instead of OIDC. Handle the "budget exceeded" error gracefully in the UI (friendly message, not a stack trace).

## Logs

Dashboard → **AI Gateway** → Logs/Observability shows every request: model, provider that served it, input/output tokens, latency (TTFT and total), cost, and errors. Use it to:
- Confirm failover and provider ordering actually happen.
- Find the prompts driving cost.
- Compare model tiers (`ai-gateway-model-tiering`).

## Attribution

Tag requests so spend can be broken down by user or feature. The gateway supports user and tag metadata through `providerOptions.gateway` (check the docs for current field names, e.g. `user` and `tags`):

```ts
providerOptions: {
  gateway: { user: session.userId, tags: ['feature:chat', 'plan:pro'] },
},
```

## App-side guards (belt and braces)

- Per-user rate limits (`firewall-rate-limiting`).
- `maxOutputTokens` on every call; `stopWhen: stepCountIs(n)` on every agent loop.
- Also set project **Spend Management** limits for functions, since agents consume compute too.

Docs: https://vercel.com/docs/ai-gateway/observability-and-spend/api-key-budgets
