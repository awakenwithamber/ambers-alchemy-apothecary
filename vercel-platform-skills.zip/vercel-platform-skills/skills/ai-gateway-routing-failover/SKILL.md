---
name: ai-gateway-routing-failover
description: Make LLM calls resilient with Vercel AI Gateway — fallback models when the primary fails, provider ordering and restriction for the same model (e.g. Bedrock vs Anthropic vs Vertex), and handling rate limits and outages for long-running agents. Use whenever the user wants failover, redundancy, uptime for AI features, to pin or prefer a provider for compliance or cost, or hits provider 429s/5xx.
---

# Routing and failover

All options go under `providerOptions.gateway` on any AI SDK call.

## Model fallbacks (different models)

```ts
import { generateText } from 'ai';

const { text } = await generateText({
  model: 'anthropic/claude-sonnet-5',           // primary
  providerOptions: {
    gateway: { models: ['openai/gpt-5', 'google/gemini-2.5-flash'] }, // fallbacks, in order
  },
  prompt,
});
```
The `models` array lists **fallbacks only** — keep the primary in `model`, don't repeat it.

## Provider order (same model, multiple hosts)

Many models are served by several providers. Control which serve your request:

```ts
providerOptions: {
  gateway: {
    order: ['bedrock', 'anthropic'], // try Bedrock first, then Anthropic direct
    // only: ['bedrock', 'vertex'],  // restrict to these providers (compliance/data residency)
  },
},
```
- `order` = preference with automatic failover down the list.
- `only` = hard allowlist; requests fail rather than use other providers.

Check which providers serve a model in the model catalog before setting these.

## Combining

Provider-level failover happens first for the primary model, then model fallbacks. Use `only` sparingly — it removes redundancy.

## Patterns

- **Chat UX**: primary frontier model + one cheaper, fast fallback so users never see an error.
- **Background agents**: fallbacks on every step; long runs will eventually meet an outage.
- **Structured output**: pick fallbacks that support the same features (tool calling, JSON/object output, vision) or the fallback will fail differently.
- **Compliance**: `only` with providers covered by your data agreements.

## Observability

Gateway logs show which provider/model actually served each request — use them to confirm failover works. Test by temporarily setting `only` to a provider that doesn't serve the model.

Docs: https://vercel.com/docs/ai-gateway/models-and-providers
