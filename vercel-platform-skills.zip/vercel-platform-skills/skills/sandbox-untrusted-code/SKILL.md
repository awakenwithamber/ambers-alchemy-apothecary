---
name: sandbox-untrusted-code
description: Security model and checklist for executing untrusted, user-submitted, or AI/LLM-generated code in Vercel Sandbox — why never eval or child_process in your app, least-privilege network, no secrets inside, timeouts, resource limits, output size caps, and per-tenant isolation. Use whenever code the developer didn't write will be executed — code interpreters, AI agents that write scripts, online judges, plugin systems, playgrounds, or "run this repo" features.
---

# Running untrusted code safely

## Never

- `eval`, `new Function`, `vm` module, or `child_process` with untrusted input in your Vercel Function. The `vm` module is **not** a security boundary.
- Pass real secrets (env vars, API keys, DB URLs) into the sandbox.
- Reuse one sandbox across different users or tenants.
- Stream unbounded output back into an LLM context or a response.

## Always

1. **One sandbox per tenant/run.** Key persistent sandboxes by run or user ID (`Sandbox.getOrCreate({ name })`), never shared.
2. **Deny network by default.** `networkPolicy: 'deny-all'` for pure computation. If it needs the network, allowlist exact hostnames only (`sandbox-network-firewall`).
3. **Install, then lock down.** Allow the registry for `npm install`/`pip install`, then `sandbox.update({ networkPolicy: 'deny-all' })` before running the untrusted part.
4. **Broker credentials.** When code must call an API, inject the credential at the firewall with `transform` so the key never enters the VM.
5. **Tight timeouts** on the sandbox and on each command; kill runaway processes.
6. **Cap output**: truncate stdout/stderr (e.g. first 20 KB) before returning to users or models.
7. **Validate inputs** you write into the sandbox (file paths — no `..`, sizes).
8. **Stop sandboxes** in `finally` blocks; don't rely on timeouts alone.
9. **Treat outputs as untrusted too**: don't render sandbox HTML unescaped in your app origin; serve previews from the sandbox's own domain.

## Minimal safe runner

```ts
import { Sandbox } from '@vercel/sandbox';

export async function runUntrusted(code: string) {
  const sandbox = await Sandbox.create({ runtime: 'node24', timeout: 60_000, networkPolicy: 'deny-all' });
  try {
    await sandbox.writeFiles([{ path: 'main.js', content: Buffer.from(code) }]);
    const cmd = await sandbox.runCommand({ cmd: 'node', args: ['main.js'] });
    const out = (await cmd.stdout()).slice(0, 20_000);
    const err = (await cmd.stderr()).slice(0, 5_000);
    return { exitCode: cmd.exitCode, out, err };
  } finally {
    await sandbox.stop();
  }
}
```

## Also protect the entry point

The route that triggers sandbox runs spends money: require auth, rate limit it (`firewall-rate-limiting`), and consider BotID (`firewall-bot-protection`).
