---
name: env-secret-rotation
description: Respond to a leaked or exposed secret and rotate credentials on Vercel without downtime — revoke at the provider, issue a new key, update vercel env in all scopes, redeploy, purge from git history, and audit usage. Use immediately when the user says a key was committed, pasted publicly, exposed in a client bundle or logs, flagged by GitHub secret scanning, or when setting up a routine rotation schedule.
---

# Secret leak response & rotation

**A leaked secret must be rotated. Deleting it from code or git history is not enough** — assume it was copied the moment it was exposed.

## Incident order (do not reorder)

1. **Revoke or roll** the key at the provider (Stripe, OpenAI, AWS, database, Clerk, etc.). Many providers support rolling with a short overlap window — use it for zero downtime.
2. **Add the new value** in every scope that had the old one:
   ```bash
   vercel env rm STRIPE_SECRET_KEY production --yes
   printf '%s' "$NEW_KEY" | vercel env add STRIPE_SECRET_KEY production
   # repeat for preview/development as applicable
   ```
3. **Redeploy** production (and active previews) so deployments stop using the old value: `vercel --prod` or redeploy from the dashboard.
4. **Confirm** the app works, then fully revoke the old key if you used an overlap window.
5. **Audit** provider logs for use of the old key between exposure and revocation.
6. **Clean history** (after rotation): `git filter-repo --replace-text` or BFG, force-push, and ask collaborators to re-clone. Enable GitHub secret scanning + push protection.
7. **Record** what leaked, when, how, and what changed.

## If it leaked into a client bundle

A secret under `NEXT_PUBLIC_` was shipped to every visitor. Rotate it, rename the variable without the prefix, move its use server-side, and redeploy.

## Reduce future blast radius

- Replace static cloud keys with OIDC (`env-oidc-tokens`).
- Use AI Gateway with OIDC or budgeted keys instead of raw provider keys (`ai-gateway-budgets-observability`).
- Mark secrets Sensitive; scope keys to least privilege; separate prod and preview keys.
- Rotate high-value secrets on a schedule (e.g. quarterly) using the same steps.
