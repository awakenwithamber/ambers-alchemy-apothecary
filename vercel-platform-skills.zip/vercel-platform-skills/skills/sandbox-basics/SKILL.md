---
name: sandbox-basics
description: Create and run Vercel Sandbox — ephemeral Firecracker microVMs — from TypeScript (@vercel/sandbox), Python, or the sandbox CLI; choose runtimes, resources, and timeouts; run commands (blocking or detached); reuse persistent named sandboxes; and stop them to control cost. Use whenever the user mentions Vercel Sandbox, microVMs, running code in isolation, spinning up a dev environment on demand, or the @vercel/sandbox package.
---

# Vercel Sandbox basics

Each sandbox is an isolated Firecracker microVM (Linux, own filesystem and network namespace) that boots in about a second. Use it for anything you shouldn't run in your app's own process: AI-generated code, user code, builds of untrusted repos, tests.

## Install & auth

```bash
npm i @vercel/sandbox
vercel link && vercel env pull   # local auth via OIDC (re-pull when it expires)
```
On Vercel, auth is automatic via OIDC. Outside Vercel, use a Vercel access token plus team and project IDs (see the SDK docs for the exact option names).

## Create, run, stop

```ts
import { Sandbox } from '@vercel/sandbox';

const sandbox = await Sandbox.create({
  runtime: 'node24',           // check docs for current runtimes (Node, Python)
  timeout: 5 * 60_000,         // ms; max depends on plan
  resources: { vcpus: 2 },
  networkPolicy: 'deny-all',   // see sandbox-network-firewall
});

try {
  const cmd = await sandbox.runCommand({ cmd: 'node', args: ['-e', 'console.log(1 + 1)'] });
  console.log(cmd.exitCode, await cmd.stdout(), await cmd.stderr());
} finally {
  await sandbox.stop();        // always stop; billing runs while it's alive
}
```

Shorthand: `await sandbox.runCommand('npm', ['install'])`.

## Detached (long-running) commands

```ts
const server = await sandbox.runCommand({ cmd: 'npm', args: ['run', 'dev'], detached: true });
// ...later
for await (const log of server.logs()) process.stdout.write(log.data);
```

## Persistent, named sandboxes

```ts
const sb = await Sandbox.getOrCreate({ name: `analysis-${runId}`, runtime: 'node24', timeout: 600_000 });
```
Same name → reattaches instead of provisioning another. Ideal inside durable workflows where steps may retry.

## CLI

```bash
sandbox create --network-policy deny-all
sandbox exec <name> -- npm test
sandbox config network-policy <name> --network-policy deny-all
```

## Cost & limits

- Billed on active CPU/memory time; stop promptly, keep timeouts tight.
- Use `extendTimeout` for legitimately long jobs rather than huge initial timeouts.
- Snapshots and custom images (from Vercel Container Registry) speed up repeated setups — see the docs.

Docs: https://vercel.com/docs/sandbox
