---
name: firewall-bot-protection
description: Stop scrapers, credential stuffers, and automated abuse on Vercel using the Bot Protection managed ruleset, AI-bot controls, and BotID invisible verification for high-value routes like signup, checkout, contact forms, and AI endpoints. Use whenever the user mentions bots, scraping, fake signups, spam form submissions, card testing, or protecting an expensive API route.
---

# Bot protection on Vercel

Two complementary tools:

1. **Bot Protection managed ruleset** (Firewall → Rules → managed rulesets). Site-wide. Challenges or logs requests identified as non-browser bots while automatically allowing **verified bots** (Googlebot, Bingbot, known webhook providers). Start in **Log**, review, then set **Challenge**.
2. **AI bots ruleset** — separately log/deny known AI crawlers if the user doesn't want content scraped for training.
3. **BotID** — invisible, CAPTCHA-free verification you call in code on specific routes. Best for actions where a bot costs money: signup, login, checkout, contact forms, LLM endpoints.

## BotID setup (Next.js)

```bash
npm i botid
```

```ts
// next.config.ts
import { withBotId } from 'botid/next/config';
const nextConfig = {};
export default withBotId(nextConfig);
```

```ts
// instrumentation-client.ts — declare which routes the client should attach proofs to
import { initBotId } from 'botid/client/core';

initBotId({
  protect: [
    { path: '/api/signup', method: 'POST' },
    { path: '/api/checkout', method: 'POST' },
    { path: '/api/chat', method: 'POST' },
  ],
});
```

```ts
// app/api/signup/route.ts
import { checkBotId } from 'botid/server';

export async function POST(req: Request) {
  const { isBot } = await checkBotId();
  if (isBot) return new Response('Access denied', { status: 403 });
  // ...real work
}
```

Every protected server route must call `checkBotId()`; the client list alone does nothing. Server Actions work too — call `checkBotId()` at the top of the action. Deep Analysis mode (paid) adds stronger detection; enable it in the Firewall dashboard.

## Choosing

| Situation | Use |
|---|---|
| Generic scraping across the site | Managed Bot Protection → Challenge |
| Specific form/API being abused | BotID on that route |
| API called by legit non-browser clients | Neither on that route — use auth + rate limiting |
| Stop AI training crawlers | AI bots ruleset → Deny |

## Gotchas

- Challenges break non-browser clients (mobile apps, server-to-server, webhooks). Scope rules or add bypasses.
- Pair BotID with `firewall-rate-limiting` on auth routes; they catch different attacks.
- Test on a preview deployment; `checkBotId()` behaves permissively in local dev.

Docs: https://vercel.com/docs/vercel-firewall/vercel-waf/managed-rulesets · https://vercel.com/docs/botid
