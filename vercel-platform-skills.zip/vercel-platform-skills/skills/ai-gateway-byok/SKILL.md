---
name: ai-gateway-byok
description: Use Bring Your Own Key (BYOK) with Vercel AI Gateway — attach your own OpenAI, Anthropic, Google, Bedrock, or other provider credentials so requests bill to your provider account and use your negotiated rates or quotas, while keeping gateway routing, fallback, and observability. Use whenever the user has existing provider credits, enterprise agreements, higher rate limits on their own account, or asks whether they can use their own API keys with AI Gateway.
---

# BYOK (Bring Your Own Key)

## When to use

- Existing provider credits or committed-spend contracts.
- Your own account has higher rate limits or special model access.
- Compliance requires requests go through your provider tenancy.

When not needed: if you just want one bill and no key management, use Gateway credits (no BYOK).

## Setup

1. Vercel dashboard → **AI Gateway** → **Bring Your Own Key** (integrations/credentials section).
2. Add the provider credential (API key, or cloud credentials for Bedrock/Vertex).
3. That's it for code — requests to that provider's models now use your key automatically. Your app still authenticates to the Gateway with OIDC or `AI_GATEWAY_API_KEY`.

## Behavior to know

- If your BYOK credential fails (bad key, quota exhausted), the gateway can fall back to its own system credentials, so the request still succeeds but bills to Gateway credits. Check current docs for how to disable that fallback if you require BYOK-only.
- Per-request credentials can also be supplied via `providerOptions.gateway` (a BYOK option) for multi-tenant apps where each customer brings their own key — verify the exact field name in the docs before using.
- Rotate BYOK keys at the provider, then update them in the Gateway dashboard; no redeploy is needed.

## Security

- Provider keys live in the Gateway dashboard, not in your repo or project env vars.
- Scope provider keys to the minimum permissions the provider allows.
- For customer-supplied keys, store them encrypted at rest and never log them.

Docs: https://vercel.com/docs/ai-gateway/byok
