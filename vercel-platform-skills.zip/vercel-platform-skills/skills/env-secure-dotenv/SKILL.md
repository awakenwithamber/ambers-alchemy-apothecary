---
name: env-secure-dotenv
description: Secure handling of .env files in Vercel/Next.js projects — which files to gitignore, load order, the NEXT_PUBLIC_ client-exposure trap, keeping secrets out of logs, client bundles, and AI agent context, and scanning for leaked keys. Use whenever the user creates or edits a .env file, adds an API key, asks where to put a secret, sees a key in source code, or sets up a new repo.
---

# Secure .env handling

## Files and gitignore

Next.js load order (later wins): `.env` → `.env.[mode]` → `.env.local` → `.env.[mode].local`. `.env.local` is ignored in `test` mode.

`.gitignore` must contain:
```
.env*
!.env.example
.vercel
```
Commit only `.env.example` with **names and dummy values**, never real values. `.vercel/` holds project linkage and should not be committed.

## Source of truth

Vercel project env vars are the source of truth. Local files are generated from them:
```bash
vercel link           # once per checkout
vercel env pull .env.local
```
Don't hand-copy secrets between machines, chat messages, or tickets.

## The client-exposure rule

Anything prefixed `NEXT_PUBLIC_` (or `VITE_`, `PUBLIC_`, `EXPO_PUBLIC_` in other frameworks) is **inlined into the browser bundle at build time** and is public.

- OK public: publishable keys (`NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY`, Stripe `pk_...`), public site URLs, analytics IDs.
- Never public: secret keys, DB URLs, `*_SECRET`, service-role keys, AI provider keys, webhook secrets.
- Changing a `NEXT_PUBLIC_` value requires a **rebuild** to take effect.

Guard server-only modules:
```ts
// lib/secrets.ts
import 'server-only';
export const stripeSecret = process.env.STRIPE_SECRET_KEY!;
```

## Keep secrets out of places they leak

- Never `console.log(process.env)` or log full request headers.
- Don't return env values in API responses or error messages.
- Don't pass secrets into Vercel Sandbox; use credential brokering (`sandbox-network-firewall`).
- AI coding agents: avoid pasting `.env.local` contents into prompts; reference variable **names**.

## Leak check (run before commits or when suspicious)

```bash
git grep -nE '(sk_live_|sk-[A-Za-z0-9]{20,}|AKIA[0-9A-Z]{16}|-----BEGIN (RSA|EC|OPENSSH) PRIVATE KEY|xox[bap]-)' || echo "no obvious secrets"
git log -p --all -S 'sk_live_' | head
```
If anything real is found, go to `env-secret-rotation` — deleting the line is not enough.

Docs: https://vercel.com/docs/environment-variables
