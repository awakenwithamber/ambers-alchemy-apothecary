---
name: firewall-overview
description: Map of the Vercel Firewall — platform DDoS mitigation, WAF custom rules, IP blocking, managed rulesets, rate limiting, Attack Challenge Mode, and BotID — and which one to use for a given threat. Use this whenever the user mentions Vercel security, firewall, WAF, blocking traffic, suspicious traffic spikes, scrapers, abuse, or "protect my site", before choosing a specific firewall skill.
---

# Vercel Firewall overview

Vercel's firewall runs at the edge in front of every deployment. Rule changes take effect globally within about 300ms **without a redeploy**. Configure it per project under **Project → Firewall**, or via the REST API (`/v1/security/firewall/config`).

## Layers (evaluated roughly in this order)

| Layer | What it does | You configure? |
|---|---|---|
| Platform DDoS mitigation | Automatic L3/L4/L7 protection on all plans | No — always on |
| IP blocking | Deny specific IPs/CIDRs per project or hostname | Yes |
| Custom rules (WAF) | If/then rules on path, headers, geo, ASN, JA3/JA4, cookies… | Yes |
| Managed rulesets | Bot Protection, AI bots, OWASP (plan-dependent) | Toggle + action |
| Rate limiting | Fixed-window limits keyed by IP, user agent, etc. | Yes |
| Attack Challenge Mode | Challenge *every* visitor during an active attack | Toggle |
| BotID | Invisible, per-route bot verification in your code | Code |

## Decision guide

- Traffic spike from a region/network you don't serve → `firewall-waf-custom-rules` (geo/ASN rule, start in Log).
- Scanners hitting `/wp-admin`, `.php`, `.env` → WAF path rule → Deny.
- Brute force on login/signup/API → `firewall-rate-limiting`.
- Scrapers and generic bots → `firewall-bot-protection` (managed ruleset).
- Bots abusing a specific high-value action (checkout, signup, AI endpoint) → BotID in `firewall-bot-protection`.
- Site is being actively hammered right now → `firewall-attack-challenge-mode` immediately, then write targeted rules.
- Preview deployments exposed or crawlable → `deployment-hardening`.

## Rules of thumb

- **Log before enforce.** Publish every new rule with the `log` action, watch the live traffic view, then switch to `deny`/`challenge`.
- **Challenge vs deny.** Deny traffic no human sends (vuln scans). Challenge traffic a real person *might* match (country, VPN, cookieless). Challenge sessions last ~1 hour.
- **Protect your own automation.** Webhooks, cron hitting public URLs, uptime monitors, and mobile/server clients cannot solve challenges. Add a `bypass` rule or system bypass first.
- **Audit log is your undo.** Firewall → ⋯ → View Audit Log restores earlier configurations.
- Firewall changes need team permissions; the agent may need the user to click Publish in the dashboard.

Docs: https://vercel.com/docs/vercel-firewall
