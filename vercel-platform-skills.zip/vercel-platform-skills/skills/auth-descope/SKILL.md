---
name: auth-descope
description: Add Descope authentication to a Next.js app on Vercel — provision via the Vercel Marketplace, AuthProvider, the Descope flow component for no-code sign-up/sign-in (passkeys, magic links, OTP, social, SSO), authMiddleware route protection, and server-side session validation. Use whenever the user mentions Descope, visual/no-code auth flows, passwordless login, or passkeys-first authentication.
---

# Descope on Next.js + Vercel

## 1. Provision

```bash
vercel integration add descope
vercel env pull .env.local
vercel env ls        # confirm the exact variable names the integration injected
```
You need the Descope **project ID** (public) and, for management APIs, a **management key** (secret). Map them to what your code reads (commonly `NEXT_PUBLIC_DESCOPE_PROJECT_ID` and `DESCOPE_MANAGEMENT_KEY`).

## 2. Install & provider

```bash
npm i @descope/nextjs-sdk
```

```tsx
// app/layout.tsx
import { AuthProvider } from '@descope/nextjs-sdk';

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <AuthProvider projectId={process.env.NEXT_PUBLIC_DESCOPE_PROJECT_ID!}>
      <html lang="en"><body>{children}</body></html>
    </AuthProvider>
  );
}
```

## 3. Sign-in page (flow built in the Descope console)

```tsx
// app/sign-in/page.tsx
'use client';
import { Descope } from '@descope/nextjs-sdk';

export default function SignIn() {
  return <Descope flowId="sign-up-or-in" redirectAfterSuccess="/dashboard" />;
}
```
Edit the flow (passkeys, magic link, OTP, social, SSO) in the Descope console — no redeploy needed.

## 4. Route protection

```ts
// proxy.ts (Next.js 16) — middleware.ts on Next.js 15 and earlier
import { authMiddleware } from '@descope/nextjs-sdk/server';

export default authMiddleware({
  projectId: process.env.NEXT_PUBLIC_DESCOPE_PROJECT_ID,
  redirectUrl: '/sign-in',
  publicRoutes: ['/', '/sign-in', '/api/webhooks/(.*)'],
});

export const config = { matcher: ['/((?!_next/static|_next/image|favicon.ico).*)'] };
```

## 5. Server-side session

```ts
import { session } from '@descope/nextjs-sdk/server';

export async function GET() {
  const s = await session();
  if (!s) return new Response('Unauthorized', { status: 401 });
  return Response.json({ userId: s.token.sub });
}
```

## Notes

- Client hooks: `useSession()`, `useUser()`, `useDescope()` (for logout).
- Verify option and export names against the installed SDK version; Descope's SDK evolves.
- Add Descope domains to your CSP.

Docs: https://docs.descope.com/getting-started/nextjs
