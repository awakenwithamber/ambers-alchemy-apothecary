---
name: auth-provider-selection
description: Choose the right authentication for a Vercel/Next.js app — BetterAuth (self-hosted library, your database), Clerk (managed, fastest UI), Descope (visual no-code flows, passkeys, B2B SSO), or Auth0 (enterprise identity, compliance) — and route to the matching setup skill. Use whenever the user asks to add login, sign-up, authentication, user accounts, SSO, passkeys, or asks which auth provider to use, before writing any auth code.
---

# Picking an auth provider

## Quick comparison

| | BetterAuth | Clerk | Descope | Auth0 |
|---|---|---|---|---|
| Model | Open-source library | Managed SaaS | Managed SaaS | Managed SaaS (Okta) |
| User data lives | Your database | Clerk | Descope | Auth0 |
| Vercel Marketplace | No (bring a DB, e.g. Neon) | Yes | Yes | Yes |
| Prebuilt UI | Minimal; you build UI | Polished components | Visual flow builder | Universal Login (hosted) |
| Strengths | Full control, no per-user fees, plugins (2FA, orgs, passkeys) | Fastest DX, orgs, user profile UI | No-code flows, passkeys, magic links, B2B SSO | Enterprise SSO, compliance, mature ecosystem |
| Watch out | You own security updates and email delivery | Per-MAU pricing at scale | Flow logic lives in their console | Configuration complexity |

## Decision rules

- Wants to own user data / avoid per-user pricing / already has Postgres → **BetterAuth** (`auth-betterauth`).
- Wants the fastest polished sign-in, organizations, and billing through Vercel → **Clerk** (`auth-clerk`).
- Wants passwordless, passkeys, or to change flows without redeploying → **Descope** (`auth-descope`).
- Enterprise customers requiring SAML/OIDC SSO, compliance, or already on Okta/Auth0 → **Auth0** (`auth-auth0`).

For managed providers, provision via the Marketplace first (`marketplace-provisioning`) so keys land in env vars automatically.

## Every provider, regardless

- Protect routes on the **server** (proxy/middleware + server-side session checks); client checks are UX only.
- Rate limit auth endpoints (`firewall-rate-limiting`) and consider BotID on signup (`firewall-bot-protection`).
- Next.js 16 renames `middleware.ts` to `proxy.ts` (export `proxy`); Next.js 15 and earlier use `middleware.ts`. Check `package.json` before creating the file.
- Allow provider domains in your CSP (`deployment-hardening`).
