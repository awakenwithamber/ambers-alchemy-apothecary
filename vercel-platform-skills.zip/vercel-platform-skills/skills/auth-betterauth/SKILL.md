---
name: auth-betterauth
description: Set up BetterAuth — the open-source TypeScript auth library — in a Next.js app on Vercel with your own Postgres (e.g. Neon from the Marketplace), email/password and social login, the catch-all API route, client hooks, server-side session checks, route protection, schema migrations, and plugins like 2FA, organizations, and passkeys. Use whenever the user mentions BetterAuth / better-auth or wants self-hosted auth that stores users in their own database.
---

# BetterAuth on Next.js

## 1. Install & env

```bash
npm i better-auth
vercel integration add neon    # if no database yet (see marketplace-provisioning)
vercel env pull .env.local
```
Env vars:
- `BETTER_AUTH_SECRET` — 32+ random bytes (`openssl rand -base64 32`), Sensitive, per environment.
- `BETTER_AUTH_URL` — the app's base URL (production domain in Production; for previews derive from `VERCEL_URL` or configure trusted origins).
- `DATABASE_URL` — from the DB integration.
- Social: e.g. `GITHUB_CLIENT_ID`, `GITHUB_CLIENT_SECRET`.

## 2. Server instance

```ts
// lib/auth.ts
import 'server-only';
import { betterAuth } from 'better-auth';
import { Pool } from 'pg';

export const auth = betterAuth({
  database: new Pool({ connectionString: process.env.DATABASE_URL }),
  emailAndPassword: { enabled: true },
  socialProviders: {
    github: {
      clientId: process.env.GITHUB_CLIENT_ID!,
      clientSecret: process.env.GITHUB_CLIENT_SECRET!,
    },
  },
});
```
Using Drizzle or Prisma? Swap in the matching adapter from `better-auth/adapters/*`.

## 3. Schema

```bash
npx @better-auth/cli generate   # emit schema for your ORM
npx @better-auth/cli migrate    # or apply directly (built-in Kysely adapter)
```

## 4. API route

```ts
// app/api/auth/[...all]/route.ts
import { auth } from '@/lib/auth';
import { toNextJsHandler } from 'better-auth/next-js';
export const { GET, POST } = toNextJsHandler(auth);
```

## 5. Client

```ts
// lib/auth-client.ts
import { createAuthClient } from 'better-auth/react';
export const authClient = createAuthClient();
// authClient.signIn.email({ email, password }), authClient.signIn.social({ provider: 'github' }),
// authClient.signOut(), authClient.useSession()
```

## 6. Server-side session + protection

```ts
import { headers } from 'next/headers';
import { redirect } from 'next/navigation';
import { auth } from '@/lib/auth';

export default async function Dashboard() {
  const session = await auth.api.getSession({ headers: await headers() });
  if (!session) redirect('/sign-in');
  return <p>Hi {session.user.name}</p>;
}
```
In `proxy.ts`/`middleware.ts`, do only a cheap cookie-presence redirect (e.g. `getSessionCookie` from `better-auth/cookies`); do the real check in the page, route, or server action.

## 7. Plugins

`twoFactor`, `organization`, `passkey`, `magicLink`, `admin` — add to `plugins: []` server-side and the matching client plugin, then re-run the CLI to update the schema.

## Production notes

- You own email delivery for verification/reset (e.g. Resend) — wire `sendVerificationEmail` / `sendResetPassword`.
- Rate limit `/api/auth/*` (`firewall-rate-limiting`); BetterAuth's built-in limiter is per-instance, the WAF is global.
- Keep `better-auth` updated; it's your security surface now.

Docs: https://www.better-auth.com/docs
