# AwakenAgain.com — Standing Instructions

Revised 2026-08-27. This is the primary revenue generator. Treat every change as production-facing.

---

## 0. Verify before you touch anything (three known conflicts)

Earlier versions of this file asserted facts that conflict with the deployed system.
Do not trust either version. Resolve these empirically in your first session and
correct this file with what you find.

| Question | Conflicting claims | How to resolve |
|---|---|---|
| **Which repo is canonical?** | `awakenwithamber/ambers-alchemy-apothecary` vs `awakenwithamber/awakenagain-com` | Open the Netlify site settings for the domain `awakenagain.com` and read the linked repo. That repo is canonical; the other is legacy. Report which one won. |
| **How big is the catalog?** | `data.js` "~345 products" vs `products.master.final.json` 36 products | `grep -c '"handle"' data.js` and compare. 345 may be a stale count, an ingredient list, or a different array. Do not assume. |
| **Which database owns orders?** | Supabase vs Neon (Netlify Postgres) | Check `netlify/functions/` imports and the Netlify environment variable names. Both may exist; determine which one production writes to. |

Note: Netlify and Vercel were both previously pointed at `awakenwithamber/build`, a
Hydrogen/Shopify scaffold incompatible with this stack. Confirm that is no longer
the case before debugging any deploy behaviour.

---

## 1. Immutable systems — do not modify without an explicit instruction naming them

These exist and work. Do not refactor, restyle, "clean up," or replace them as a
side effect of another task.

| System | What must not change |
|---|---|
| **Background music / audio player** | Playback logic, autoplay behavior, controls, track list, volume state. Oscillators are at exactly 333Hz, 444Hz, 777Hz, 134Hz, gain 0.008 each, opt-in consent modal, no autoplay. These values are frequently corrupted by agents — do not "round" or "simplify" them. |
| **Site theme** | Deep plum `#150b26` / `#1f1336`, gold `#d4af37`, fonts `Cinzel Decorative` + `EB Garamond`, all existing layout and visual identity |
| **Herbal Quiz** | Question flow, scoring/matching logic, result rendering, lead capture |
| **Custom Remedies system** | Remedy builder logic and data model |
| **Soap Builder** | Interaction model and pacing — see §3 |

If a requested change *requires* touching one of these, say so before editing and
state exactly what will change and why.

---

## 2. Herbal Quiz endpoint contract

Every quiz endpoint response must return, for each recommendation:

1. The **suggested herb(s)** — name and why it matched
2. The **preparation format the customer selected** — balm, salve, tea, tincture, capsule, oil, bath soak, etc.
3. The matching purchasable product/SKU where one exists

A quiz result that returns herbs without the requested preparation format is a bug,
not a partial success. Never drop the format field to simplify a payload.

---

## 3. Soap Builder must stay a game

The soap builder is a mini-game, not a form. Preserve: step-by-step reveal, visual
feedback on each selection, playful copy, sense of progression and payoff at the end.

Do not "simplify" it into a dropdown checkout flow. If a change would reduce
interactivity, flag it instead of shipping it.

---

## 4. Payment architecture (locked — Aug 2026)

**Approved:**
- PayPal — the only integrated processor. Orders created and captured server-side,
  webhook signatures verified, totals recalculated server-side, no PayPal secrets in
  client code, no raw card numbers collected on-site.
- Cash App `$AmberPatten92` — manual. Customer includes the order number in the
  payment note; status stays Awaiting Payment until Amber verifies.
- Venmo — **disabled** behind `VENMO_ENABLED` until the handle is verified with a
  live link test.

**Forbidden — never add, restore, or scaffold:**
Stripe, Shopify, Square, Gumroad, Klarna, Afterpay, and the retired Cash App handle
`$AmberAlchemy`.

If you find dead references to any of the above, report them. Remove only when asked.
A legacy file containing a live Stripe payment link was previously quarantined; if
you encounter it, report rather than delete.

---

## 5. Data and integration invariants

- Cart localStorage key is `aa_cart`, shape `[{id, qty}]`. Do not rename or reshape it — existing customer carts depend on it.
- **`products.master.final.json` is the canonical product catalog** (36 products, 7 categories). It supersedes `products.json` and `ambers_alchemy_products_for_automation_ai.json`, both of which are retired and must not be reintroduced.
- Serverless functions live **only** in `netlify/functions/`. Netlify does not deploy `/api/`. Never recreate an `/api/` folder.
- Never write a migration, reset, or destructive query against the orders database without explicit approval — see §0 for which database that is.
- Grimoire content gating must be verified **server-side** and return only a boolean. Never place gated content in page source or rely on CSS hiding. Access is granted to `awaken@consultant.com` or to confirmed active $7.77/month subscribers only; canceled, expired, and failed subscriptions are denied.

---

## 6. Images

- All product images are self-hosted at `/images/products/<handle>.webp` with a
  `.png` fallback. The filename must match the product handle exactly, lowercase.
- **Never** reference `drive.google.com`, `googleusercontent.com`, Dropbox, or an
  absolute `https://awakenagain.com/...` URL. Google Drive is not a CDN — it
  redirects, rate-limits, and returns an HTML interstitial instead of image bytes.
  This was the original cause of the broken-image problem and the commit guard now
  blocks its return.
- **`image-status.json` tracks which images are real photographs and which are
  generated placeholder cards.** Placeholder cards show the product name on a plum
  background with no product in them. They are acceptable as a temporary fallback
  but must never be presented as product photography, used in ads, or submitted to
  a merchant feed. When a real photo replaces a placeholder, move the handle from
  `placeholder` to `photo` in that file.
- Because `/images/*` is served with `immutable` cache headers, replacing an image
  at the same filename will not refresh for returning visitors. Change the filename
  (append `-v2`) when swapping artwork.

---

## 7. Claims language

This is a wellness brand, not a medical one.

- Do not write or restore disease claims: "cures," "treats [condition]," "heals [condition]"
- Preferred phrasing: "traditionally used to support…"
- "Remedy / remedies" is approved brand vocabulary and may stay
- Every product and quiz result surface needs the FDA disclaimer reachable via footer or small-print link

**Retired terms — an Aug 2026 compliance pass removed these. Their reappearance in
customer-facing copy means a rename was reverted:** PTSD, bipolar, diabetic /
diabetes, blood sugar, parasite cleanse, heavy metal detox, hair regrowth, age
reversal, miracle, pain relief, and named-biomarker claims (serotonin, oxytocin,
endorphins, insulin).

Renamed products and their redirects are in `netlify-redirects.toml` (23 entries).
Do not restore an old product name without also removing its redirect.

Check `alt_text` as well as body copy — a rename that misses alt text leaves the old
claim live for screen readers and image search.

---

## 8. Secrets

Never read, print, echo, or commit: `.env`, `.env.*`, `.replit`, anything under
`secrets/`, or Netlify environment variable values.

This applies through **every** tool surface. `Read(./.env)` being denied does not
make `cat .env`, `grep x .env`, `printenv`, or `netlify env:list` acceptable — the
settings file now denies those explicitly, and circumventing them by another route
is a policy violation regardless of whether a rule happens to match.

This repo is public and has a history of leaked credentials. If you encounter a
credential in a file or in git history, stop and report it — do not paste it into
output. A Resend API key was previously exposed and required rotation.

---

## 9. How to work in this repo

1. **Plan before coding.** State the objective, map dependencies, name what could break.
2. **Verify assumptions** against the actual files. Do not assume a file's contents from its name, and do not assume this document is current — see §0.
3. **Smallest change that achieves the goal.** No opportunistic refactors.
4. **After every change**: state what changed, what was verified, and what still needs manual testing.
5. **Never sacrifice functionality for appearance.** Improvements to SEO, conversion, accessibility, mobile responsiveness, and page speed are welcome — regressions to working features are not.
6. **No self-approval on high-risk changes.** Payments, auth, order data, product catalog, and DNS changes get reviewed by a second agent or by Amber before merge.
7. **Do not report a fix as verified because a file exists.** A path that resolves is not a working image; a build that succeeds is not a working page. Verify against the deploy preview URL, not localhost.

---

## 10. Definition of done

Accurate · functional · optimized · mobile-friendly · SEO-friendly · secure ·
scalable · documented · tested — and no immutable system in §1 was altered.
