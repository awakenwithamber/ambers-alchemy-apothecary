AWAKENAGAIN.COM — CORRECTED DEPLOYMENT PACKAGE
Generated 2026-08-27

CONTENTS
  CLAUDE.md                  Standing instructions, revised
  settings.json              Claude Code permissions, secret-read hole closed
  pre-commit                 Commit guard, claims + external-host rules added
  netlify-redirects.toml     23 legacy product URL redirects
  products.master.final.json Canonical catalog, 36 products
  image-status.json          Which images are real photos vs placeholders
  images/products/           36 .webp + 36 .png, 1200x1200

INSTALL
  cp CLAUDE.md ./CLAUDE.md
  mkdir -p .claude && cp settings.json .claude/settings.json
  cp pre-commit .git/hooks/pre-commit && chmod +x .git/hooks/pre-commit
  cp -r images/products public/images/products      # adjust to your publish dir
  cp products.master.final.json image-status.json ./
  # paste netlify-redirects.toml contents into netlify.toml

WHAT CHANGED
  - 7 real product photographs replace generated placeholder cards
    (gaias-rose, orange-lily-goddess, lavender-fairy-dream, sacred-forest-ritual,
     eucalyptus-mint-spa-renewal, warm-cinnamon-comfort soaps; dreamease-capsules)
  - 29 products still carry placeholder cards, tracked in image-status.json
  - settings.json: Read(./.env) denial no longer bypassable via cat/grep/printenv/
    netlify env:list; blanket `git add*` moved from allow to ask
  - pre-commit: claims regex now covers PTSD, bipolar, diabetic, blood sugar,
    parasite, heavy metal, regrowth, age reversal, miracle; new rule blocks
    Google Drive and absolute image URLs
  - CLAUDE.md: three factual conflicts (repo, catalog size, database) converted
    from assertions into a mandatory §0 verification step

STILL OUTSTANDING
  - Photograph the remaining 29 products
  - Confirm the 6 soap photo assignments are the correct bars
  - 333 herbal index cards not located
